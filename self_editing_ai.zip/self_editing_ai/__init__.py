"""Top‑level package for the self‑editing AI library."""

from .src.agent.loop import AgentLoop  # noqa: F401
from .src.agent.memory import Memory  # noqa: F401