"""Self‑editing AI agent package.

This package contains modules that together implement an autonomous agent capable
of modifying its own code.  The top‑level modules include:

* `loop.py` – the planning/editing/testing/reviewing loop that drives the agent.
* `tools.py` – utility functions for searching the web, reading and writing files,
  executing Python code, embedding text, etc.
* `memory.py` – a simple SQLite‑backed memory and vector store for storing
  conversational history and code embeddings.
* `edits.py` – helpers for generating and applying AST or unified diff patches.
* `tests_runner.py` – a wrapper around pytest used to run the project's
  own test suite to evaluate changes.
* `policies.py` – definitions of safety policies governing what the agent is
  allowed to do.

Note that this package is designed to be modified by the agent itself.  Keep
your code clear and well documented so that the agent can understand and
improve it.
"""

from .loop import AgentLoop  # noqa: F401 re‑export